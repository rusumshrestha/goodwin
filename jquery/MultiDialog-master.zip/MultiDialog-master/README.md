# [jQuery MultiDialog](http://fnagel.github.com/MultiDialog/) 

[![Build Status](https://drone.io/github.com/fnagel/MultiDialog/status.png)](https://drone.io/github.com/fnagel/MultiDialog/latest)

MultiDialog utilizes jQuery UI Dialog Widget for a full featured Modalbox / Lightbox application.

Please see http://fnagel.github.com/MultiDialog/ for more information.

# Download

* **Stable releases**: [GitHub releases](https://github.com/fnagel/MultiDialog/releases)
* **Latest development version**: [Drone.io asserts](https://drone.io/github.com/fnagel/MultiDialog/files)