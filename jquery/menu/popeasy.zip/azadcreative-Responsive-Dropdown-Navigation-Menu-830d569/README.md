Building a Responsive, Mobile-First Navigation Menu
==================================================

Here lies the source code for the [Building a Responsive, Mobile-First Navigation Menu](http://azadcreative.com/2012/06/responsive-mobile-first-navigation-menu/)

Browse the [Live Demonstration](http://bit.ly/respnav) using your mobile, tablet and desktop browsers. Fork away and if you find any bugs, please report to Saddam Azad, saddam -dot- azad -at- me -dot- com.


Credits:
--------

* [320 and Up](http://stuffandnonsense.co.uk/projects/320andup/) by Andy Clarke.
* [HTML5 Boilerplate Mobile](http://html5boilerplate.com/mobile/)
* [Bootstrap](http://twitter.github.com/bootstrap/) by Twitter.
* [Overthrow.js](https://github.com/filamentgroup/Overthrow/) by Filament Group