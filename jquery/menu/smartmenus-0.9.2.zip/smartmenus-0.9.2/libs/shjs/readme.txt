SmartMenus jQuery DOES NOT depend on SHJS so you probably don't need it on your pages.

It is just used for syntax highlighting of the code samples on the demo page.