jquery-css-dropdown-plugin
==========================

Lightweight, Simple, Styleable jQuery + CSS Dropdown Menu Plugin

View the README and see demonstrations at the plugin homepage:

http://danielupshaw.com/jquery-css-dropdown-plugin/readme.html
