# Camera slideshow 
A jQuery slideshow with many effects, transitions, easy to customize, using canvas and mobile ready, based on jQuery 1.4+

# Requirements
Camera slideshow requires jQuery 1.4+ and other jQuery plugins are necessary if you want to use some functionalities: jQuery Easing (http://gsgd.co.uk/sandbox/jquery/easing/) and a customized version of jQuery Mobile (http://jquerymobile.com/) to use Camera with mobile devices

# Copyright
Copyright (c) 2012 by Manuel Masia - http://www.pixedelic.com

Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php

# Support
http://groups.google.com/group/camera-slideshow

